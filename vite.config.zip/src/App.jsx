import React, { useState, useEffect, useRef } from 'react';
import {
  CalendarDays,
  Users,
  Stethoscope,
  LogOut,
  User2
} from 'lucide-react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import './App.css';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

export default function App() {
  const [categories, setCategories] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedDoctor, setSelectedDoctor] = useState('');
  const [loading, setLoading] = useState({ categories: true, doctors: false, appointments: false });
  const [error, setError] = useState('');

  const [showLogin, setShowLogin] = useState(() => !localStorage.getItem('loggedIn'));
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);

  const [patientsCount, setPatientsCount] = useState(null);
  const [patientRateData, setPatientRateData] = useState(null);
  const [loadingPatients, setLoadingPatients] = useState(false);

  useEffect(() => {
    fetch('http://localhost:8000/categories')
      .then(res => res.json())
      .then(data => setCategories(data.categories))
      .catch(() => setError('Failed to load categories.'))
      .finally(() => setLoading(prev => ({ ...prev, categories: false })));
  }, []);

  useEffect(() => {
    if (!selectedCategory) {
      setDoctors([]);
      setSelectedDoctor('');
      setAppointments([]);
      return;
    }

    setLoading(prev => ({ ...prev, doctors: true }));
    fetch(`http://localhost:8000/doctors?category=${encodeURIComponent(selectedCategory)}`)
      .then(res => res.json())
      .then(data => setDoctors(data.doctors))
      .catch(() => setError('Failed to load doctors.'))
      .finally(() => setLoading(prev => ({ ...prev, doctors: false })));

    setSelectedDoctor('');
    setAppointments([]);
  }, [selectedCategory]);

  useEffect(() => {
    if (!selectedDoctor) {
      setAppointments([]);
      return;
    }

    setLoading(prev => ({ ...prev, appointments: true }));
    fetch(`http://localhost:8000/appointments?doctor_id=${selectedDoctor}`)
      .then(res => res.json())
      .then(data => setAppointments(data.appointments))
      .catch(() => setError('Failed to load appointments.'))
      .finally(() => setLoading(prev => ({ ...prev, appointments: false })));
  }, [selectedDoctor]);

  useEffect(() => {
    if (showLogin) return;
    if (selectedCategory || selectedDoctor) return;

    setLoadingPatients(true);
    setError('');
    fetch('http://localhost:8000/patients/count')
      .then(res => res.json())
      .then(data => {
        setPatientsCount(data.patients_count);
      })
      .catch(() => setError('Failed to load patients count.'))
      .finally(() => setLoadingPatients(false));

    fetch('http://localhost:8000/patients/rate')
      .then(res => res.json())
      .then(data => {
        setPatientRateData(data);
      })
      .catch(() => setError('Failed to load patient rate data.'));
  }, [showLogin, selectedCategory, selectedDoctor]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownOpen(false);
      }
    };

    if (dropdownOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    } else {
      document.removeEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [dropdownOpen]);

  const handleLoginSubmit = () => {
    if (!username.trim() || !password.trim()) {
      setLoginError('Please fill out both username and password.');
      return;
    }

    if (username === 'admin' && password === '123') {
      setLoginError('');
      setShowLogin(false);
      localStorage.setItem('loggedIn', 'true');
    } else {
      setLoginError('Wrong credentials.');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('loggedIn');
    setShowLogin(true);
    setUsername('');
    setPassword('');
    setDropdownOpen(false);
  };

  const chartData = {
    labels: patientRateData?.dates || [],
    datasets: [
      {
        label: 'Patient Rate',
        data: patientRateData?.counts || [],
        fill: false,
        backgroundColor: 'rgb(59, 130, 246)',
        borderColor: 'rgba(59, 130, 246, 0.7)',
        tension: 0.3,
      }
    ],
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: { display: true, position: 'top' },
      title: { display: true, text: 'Patient Rate Over Time' },
    },
    scales: {
      y: { beginAtZero: true }
    }
  };

  return (
    <div className="app-container">
      <header className="header">
        <div className="header-left">
          <Stethoscope className="icon-header" size={33} />
          <h1 className="main-title">Medical Appointment Dashboard</h1>
        </div>
        <div className="header-right" style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          {!showLogin && (
            <>
              {/* Admin Dropdown */}
              <div className="admin-dropdown" ref={dropdownRef}>
                <button
                  className="admin-button"
                  onClick={() => setDropdownOpen(!dropdownOpen)}
                  aria-label="Admin menu"
                >
                  <User2 size={20} style={{ marginRight: 6 }} />
                </button>
                {dropdownOpen && (
                  <div className="dropdown-menu">
                    <div className="dropdown-item" onClick={handleLogout}>
                      <LogOut size={16} />
                      <span>Logout</span>
                    </div>
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </header>

      <div
        className="body-container"
        style={{
          filter: showLogin ? 'blur(3px)' : 'none',
          pointerEvents: showLogin ? 'none' : 'auto',
          userSelect: showLogin ? 'none' : 'auto',
        }}
      >
        <aside className="sidebar">
          <div className="sidebar-section">
            <h3><Users size={18} /> Specialties</h3>
            <select
              value={selectedCategory}
              onChange={e => setSelectedCategory(e.target.value)}
              disabled={loading.categories || showLogin}
              className="sidebar-select"
            >
              <option value="">-- Select Specialty --</option>
              {categories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
            {loading.categories && <p className="loading">Loading...</p>}
          </div>

          <div className="sidebar-section">
            <h3><Stethoscope size={18} /> Doctors</h3>
            <select
              value={selectedDoctor}
              onChange={e => setSelectedDoctor(e.target.value)}
              disabled={!selectedCategory || loading.doctors || showLogin}
              className="sidebar-select"
            >
              <option value="">-- Select Doctor --</option>
              {doctors.map(doc => (
                <option key={doc.id} value={doc.id}>{doc.name}</option>
              ))}
            </select>
            {loading.doctors && <p className="loading">Loading...</p>}
          </div>
        </aside>

        <main className="main-content new-main-content">
          {error && <div className="error-alert">{error}</div>}

          {!showLogin && !selectedCategory && !selectedDoctor ? (
            <div className="dashboard-cards-row">
              <div className="dashboard-card stat-card">
                <div className="stat-icon stat-patient">
                  <svg
                    width="32"
                    height="32"
                    fill="none"
                    stroke="#2563eb"
                    strokeWidth="2"
                    viewBox="0 0 24 24"
                  >
                    <circle cx="12" cy="7" r="4" />
                    <path d="M5.5 21a7.5 7.5 0 0113 0" />
                  </svg>
                </div>
                <div className="stat-info">
                  <div className="stat-label">Total Specialties</div>
                  <div className="stat-value">{categories.length}</div>
                </div>
              </div>

              <div className="dashboard-card stat-card">
                <div className="stat-icon stat-today">
                  <svg
                    width="32"
                    height="32"
                    fill="none"
                    stroke="#0ea5e9"
                    strokeWidth="2"
                    viewBox="0 0 24 24"
                  >
                    <circle cx="12" cy="12" r="10" />
                    <path d="M12 6v6l4 2" />
                  </svg>
                </div>
                <div className="stat-info">
                  <div className="stat-label">Total Doctors</div>
                  <div className="stat-value">{doctors.length}</div>
                </div>
              </div>

              <div className="dashboard-card stat-card">
                <div className="stat-icon stat-appointments">
                  <svg
                    width="32"
                    height="32"
                    fill="none"
                    stroke="#fbbf24"
                    strokeWidth="2"
                    viewBox="0 0 24 24"
                  >
                    <rect x="3" y="3" width="18" height="18" rx="4" />
                    <path d="M8 7V3m8 4V3" />
                  </svg>
                </div>
                <div className="stat-info">
                  <div className="stat-label">Total Appointments</div>
                  <div className="stat-value">{appointments.length}</div>
                </div>
              </div>
            </div>
          ) : !showLogin && (selectedCategory || selectedDoctor) ? (
            <section className="appointments-section">
              <div className="appointments-header">
                <CalendarDays className="icon" size={24} />
                <h2>Appointments</h2>
              </div>
              <table className="appointments-table">
                <thead>
                  <tr>
                    <th>Pno</th>
                    <th>Appointment ID</th>
                    <th>Time</th>
                    <th>Patient ID</th>
                    <th>Patient Name</th>
                  </tr>
                </thead>
                <tbody>
                  {appointments.length > 0 ? (
                    appointments.map((appt, index) => (
                      <tr key={appt.id}>
                        <td>{index}</td>
                        <td>{appt.appointment_id}</td>
                        <td>{appt.appointment_time}</td>
                        <td>{appt.patient_id}</td>
                        <td>{appt.patient_name}</td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="5" style={{ textAlign: 'center' }}>
                        {loading.appointments ? 'Loading appointments...' : 'No appointments found.'}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </section>
          ) : null}
        </main>
      </div>

      {showLogin && (
        <div className="login-modal">
          <div className="login-container">
            <h2>Admin Login</h2>
            <input
              type="text"
              placeholder="Username"
              value={username}
              onChange={e => setUsername(e.target.value)}
              autoFocus
              className="login-input"
            />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="login-input"
              onKeyDown={e => { if (e.key === 'Enter') handleLoginSubmit(); }}
            />
            {loginError && <div className="login-error">{loginError}</div>}
            <button onClick={handleLoginSubmit} className="login-button">Login</button>
          </div>
        </div>
      )}
    </div>
  );
}

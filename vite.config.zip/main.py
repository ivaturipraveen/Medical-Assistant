from fastapi import FastAPI, Request, Response
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import psycopg2
import difflib
import json
from datetime import datetime,timedelta
import calendar

app = FastAPI()

origins = [
    "http://localhost:5173",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,           
    allow_credentials=True,
    allow_methods=["*"],              
    allow_headers=["*"],              
)


conn = psycopg2.connect(
    user="postgres",
    password="Yanthraa123",
    host="medicaldb-instance-1.c38m48coaic4.us-east-1.rds.amazonaws.com",
    port=5432,
    database="medicaldb"
)
cursor = conn.cursor()

def format_email(email):
    if not email:
        return "temp@gmail.com"
    email = email.strip()
    if "@" not in email:
        email = f"{email}@gmail.com"
    return email

@app.post("/validate-users")
async def validate_users(request: Request):
    try:
        data = json.loads(await request.body())
        print("Received JSON:", data)

        FirstName = data.get("FirstName", "").strip()
        LastName = data.get("LastName", "").strip()
        dob_str = data.get("dob", "").strip()

        if not FirstName or not LastName:
            return JSONResponse(
                content={"error": "First name and last name are required"},
                status_code=422
            )

        if not dob_str or dob_str.lower() == 'null':
            return JSONResponse(
                content={"error": "Date of birth is required"},
                status_code=422
            )

        full_name = f"{FirstName} {LastName}"

        def parse_month(month_str):
            try:
                # Try parsing as number first
                month_num = int(month_str)
                if 1 <= month_num <= 12:
                    return month_num
            except ValueError:
                # Try parsing as month name
                month_str = month_str.lower()
                for i, month_name in enumerate(calendar.month_name[1:], 1):
                    if month_str in month_name.lower():
                        return i
                for i, month_abbr in enumerate(calendar.month_abbr[1:], 1):
                    if month_str in month_abbr.lower():
                        return i
            return None

        def clean_date_string(date_str):
            # Remove common suffixes and extra spaces
            date_str = date_str.lower()
            # Remove commas
            date_str = date_str.replace(',', ' ')
            # Remove ordinal suffixes
            for suffix in ['st', 'nd', 'rd', 'th']:
                date_str = date_str.replace(suffix, '')
            # Clean up multiple spaces and trim
            return ' '.join(date_str.split())

        def parse_custom_date(date_str):
            try:
                # Clean the date string
                date_str = clean_date_string(date_str)
                parts = date_str.split()

                if len(parts) == 1:  # Only year
                    if len(parts[0]) == 4 and parts[0].isdigit():
                        return f"{parts[0]}/01/01"
                    return None

                # Try different combinations
                for i in range(len(parts)):
                    # Try current part as year first (to handle formats like "2004 January 6")
                    if parts[i].isdigit() and len(parts[i]) == 4:
                        year = parts[i]
                        remaining_parts = parts[:i] + parts[i+1:]
                        
                        # Look for month and day in remaining parts
                        for j in range(len(remaining_parts)):
                            month = parse_month(remaining_parts[j])
                            if month:
                                # Found month, look for day
                                day_candidates = [p for p in remaining_parts if p.isdigit()]
                                for day_str in day_candidates:
                                    day = int(day_str)
                                    if 1 <= day <= 31:
                                        return f"{year}/{month:02d}/{day:02d}"

                    # Try current part as month
                    month = parse_month(parts[i])
                    if month:
                        # Look for day and year in remaining parts
                        day_candidates = [p for p in parts if p.isdigit() and len(p) <= 2]
                        year_candidates = [p for p in parts if p.isdigit() and len(p) == 4]
                        
                        if day_candidates and year_candidates:
                            day = int(day_candidates[0])
                            year = year_candidates[0]
                            if 1 <= day <= 31:
                                return f"{year}/{month:02d}/{day:02d}"

                    # Try current part as day
                    if parts[i].isdigit() and len(parts[i]) <= 2:
                        day = int(parts[i])
                        if 1 <= day <= 31:
                            # Look for month and year
                            for j in range(len(parts)):
                                if i != j:
                                    month = parse_month(parts[j])
                                    if month:
                                        # Found month, look for year
                                        year_candidates = [p for p in parts if p.isdigit() and len(p) == 4]
                                        if year_candidates:
                                            return f"{year_candidates[0]}/{month:02d}/{day:02d}"

                return None
            except Exception as e:
                print(f"Date parsing error: {str(e)}")
                return None

        # First try the custom date parser
        parsed_date = parse_custom_date(dob_str)
        if parsed_date:
            dob = datetime.strptime(parsed_date, "%Y/%m/%d").date()
        else:
            # Try standard formats as fallback
            date_formats = [
                "%Y-%m-%d",    # 2024-03-15
                "%Y%m%d",      # 20240315
                "%Y/%m/%d",    # 2024/03/15
                "%d-%m-%Y",    # 15-03-2024
                "%d/%m/%Y",    # 15/03/2024
                "%m/%d/%Y",    # 03/15/2024
            ]

            dob = None
            for date_format in date_formats:
                try:
                    dob = datetime.strptime(dob_str, date_format).date()
                    break
                except ValueError:
                    continue

        if dob is None:
            return JSONResponse(
                content={"error": "Invalid date format. Please provide date in format like '29 November 2003' or '29 11 2003'"},
                status_code=422
            )

        # Check if patient exists
        cursor.execute(
            "SELECT id, full_name, dob, email FROM patients WHERE full_name = %s AND dob = %s;",
            (full_name, dob)
        )
        result = cursor.fetchone()

        if result:
            patient_id, name, date_of_birth, email = result
            # Check for appointments after we have patient_id
            cursor.execute(
                "SELECT 1 FROM appointments WHERE patient_id = %s LIMIT 1;",
                (patient_id,)
            )
            has_appointment = bool(cursor.fetchone())

            return JSONResponse(
                status_code=200,
                content={
                    "message": "Patient exists.",
                    "appointment": has_appointment,
                    "patient_id": patient_id,
                    "full_name": name,
                    "dob": str(date_of_birth),
                    "email": format_email(email)
                }
            )
        else:
            # Create new patient
            email = format_email(None)  # This will return temp@gmail.com
            cursor.execute(
                """
                INSERT INTO patients (full_name, dob, email, doctor_id, status)
                VALUES (%s, %s, %s, %s, %s)
                RETURNING id;
                """,
                (full_name, dob, email, 1, 'active')
            )
            new_id = cursor.fetchone()[0]
            conn.commit()

            # New patients won't have appointments yet
            has_appointment = False

            return JSONResponse(
                status_code=201,
                content={
                    "message": "New patient created.",
                    "appointment": has_appointment,
                    "patient_id": new_id,
                    "full_name": full_name,
                    "dob": str(dob),
                    "email": email
                }
            )

    except Exception as e:
        print("Error:", str(e))
        return JSONResponse(
            content={"error": "Server error", "details": str(e)},
            status_code=500
        )
    
    
@app.post("/get-doctors")
async def get_doctors(request : Request):
    d = json.loads(await request.body())
    print("Received JSON:", d)
    raw_department=d["department"].lower()
    try:
        cursor.execute("SELECT DISTINCT LOWER(department) FROM doctors;")
        departments = [row[0] for row in cursor.fetchall()]

        match = difflib.get_close_matches(raw_department, departments, n=1, cutoff=0.5)
        if match:
            corrected_department = match[0]
        else:
            corrected_department = raw_department 
        cursor.execute("SELECT name FROM doctors WHERE LOWER(department) = %s", (corrected_department,))
        rows = cursor.fetchall()

        if not rows:
            return {"response": f"{departments}"}

        doctor_names = [row[0] for row in rows]
        print(doctor_names)
        response_text = ", ".join(doctor_names)
        return {"response": response_text}

    except Exception as e:
        return {"error": str(e)}

def split_time_range(time_range: str):
    try:
        # Clean and split the time string
        start_str, end_str = [t.strip().upper().replace(" ", "") for t in time_range.split("-")]

        # Parse time to datetime objects
        start_time = datetime.strptime(start_str, "%I:%M%p")
        end_time = datetime.strptime(end_str, "%I:%M%p")

        # Generate 30-minute slots
        intervals = []
        while start_time < end_time:
            next_time = start_time + timedelta(minutes=30)
            interval_str = f"{start_time.strftime('%I:%M %p')} - {next_time.strftime('%I:%M %p')}"
            intervals.append(interval_str)
            start_time = next_time

        return intervals
    except Exception as e:
        raise ValueError(f"Invalid time format: {e}")

@app.post("/time-slot")
async def get_time_slot(request: Request):
    try:
        body = await request.json()
        doctor_name = body["d_name"].strip().lower()

        cursor.execute(
            "SELECT available_timings FROM doctors WHERE LOWER(name) = %s",
            (doctor_name,)
        )
        result = cursor.fetchone()

        if not result:
            return JSONResponse(
                content={"response": f"No doctor found with name '{doctor_name}'."},
                status_code=404
            )

        time_range = result[0]

        slots = split_time_range(time_range)
        return JSONResponse(content={"response": slots}, status_code=200)

    except Exception as e:
        return JSONResponse(
            content={"error": str(e)},
            status_code=500
        )
    
@app.post("/book-appointment")
async def book_appointment(request: Request):
    try:
        body = await request.json()
        print("📥 Request Body:", body)

        doctor_name = body["dname"].strip().lower()
        desired_slot = body["sslot"].strip()  # e.g. "11:00AM - 11:30AM"
        patient_id = body["pid"]
        email = format_email(body["Email"])

        # Step 1: Fetch doctor ID and max patients
        cursor.execute("SELECT id, max_patients FROM doctors WHERE LOWER(name) = %s", (doctor_name,))
        doctor = cursor.fetchone()

        if not doctor:
            return JSONResponse({"error": f"Doctor '{doctor_name}' not found."}, status_code=404)

        doctor_id, max_patients = doctor

        if max_patients <= 0:
            return JSONResponse({"response": f"No available slots for Dr. {doctor_name.title()}."}, status_code=409)

        # Step 2: Extract full appointment datetime
        start_time_str = desired_slot.split("-")[0].strip()  # "11:00AM"
        appointment_datetime = datetime.strptime(start_time_str, "%I:%M %p")

        # Combine today's date with the time
        today = datetime.today()
        full_datetime = datetime.combine(today.date(), appointment_datetime.time())

        cursor.execute("UPDATE patients SET email = %s WHERE id = %s", (email, patient_id))

        # Step 3: Reduce max_patients
        cursor.execute("UPDATE doctors SET max_patients = max_patients - 1 WHERE id = %s", (doctor_id,))

        # Step 4: Insert into appointments
        cursor.execute("""
            INSERT INTO appointments (patient_id, doctor_id, appointment_time, status, duration)
            VALUES (%s, %s, %s, %s, %s)
            RETURNING id
        """, (patient_id, doctor_id, full_datetime, "scheduled", 30))

        appointment_id = cursor.fetchone()[0]
        conn.commit()

        return {
            "message": "Appointment booked successfully.",
            "appointment_id": appointment_id,
            "doctor_name": doctor_name.title(),
            "patient_id": patient_id,
            "appointment_timing": full_datetime.strftime("%Y-%m-%d %I:%M %p"),
            "status": "scheduled",
            "time_duration": 30,
            "remaining_slots": max_patients - 1
        }

    except Exception as e:
        print("❌ Error booking appointment:", str(e))
        return JSONResponse(
            content={"error": "Failed to book appointment", "details": str(e)},
            status_code=500
        )


@app.post("/get-appointment")
async def get_appointment(request: Request):
    try:
        body = await request.json()
        patient_id = body.get("pid")
        if not patient_id:
            return JSONResponse({"error": "pid is required"}, status_code=422)

        # Join appointments → doctors to fetch everything in one query
        cursor.execute("""
            SELECT
                a.id,
                d.name      AS doctor_name,
                d.department,
                a.appointment_time
            FROM appointments a
            JOIN doctors d ON a.doctor_id = d.id
            WHERE a.patient_id = %s
            ORDER BY a.appointment_time;
        """, (patient_id,))

        rows = cursor.fetchall()

        if not rows:
            return JSONResponse(
                {
                    "appointment": False,
                    "appointment_id": None,
                    "doctor_name": None,
                    "department": None,
                    "appointment_time": None
                },
                status_code=200
            )

        # If there are multiple appointments, take the most recent one
        latest_appt = rows[-1]
        appt_id, doctor_name, department, appt_time = latest_appt

        return JSONResponse(
            {
                "appointment": True,
                "appointment_id": appt_id,
                "doctor_name": doctor_name,
                "department": department,
                "appointment_time": appt_time.strftime("%Y-%m-%d %I:%M %p")
            },
            status_code=200
        )

    except Exception as e:
        print("❌ Error fetching appointments:", e)
        return JSONResponse(
            {"error": "Server error", "details": str(e)},
            status_code=500
        )



# 1. Categories endpoint
@app.get('/categories')
def get_categories():
    cursor.execute("SELECT DISTINCT department FROM doctors;")
    cats = [row[0] for row in cursor.fetchall()]
    return {'categories': cats}

# 2. Doctors by category
@app.get('/doctors')
def get_doctors(category: str):
    cursor.execute(
        "SELECT id, name FROM doctors WHERE department = %s;",
        (category,)
    )
    rows = cursor.fetchall()
    return {'doctors': [{'id': r[0], 'name': r[1]} for r in rows]}

@app.get("/patients/count")
async def get_patients_count():
    try:
        cursor.execute("SELECT COUNT(*) FROM patients;")
        count = cursor.fetchone()[0]
        return JSONResponse(content={"patients_count": count})
    except Exception as e:
        return JSONResponse(content={"error": str(e)}, status_code=500)
@app.get('/appointments')
def get_appointments(doctor_id: int):
    print( "Doctor ID:", doctor_id)
    cursor.execute("""
        SELECT
            a.id,
            a.appointment_time,
            a.patient_id,
            p.full_name
        FROM appointments a
        JOIN patients p ON a.patient_id = p.id
        WHERE a.doctor_id = %s
        ORDER BY a.appointment_time;
    """, (doctor_id,))
    rows = cursor.fetchall()

    return {
        'appointments': [
            {
                'appointment_id': r[0],
                'appointment_time': r[1].strftime('%Y-%m-%d %I:%M %p'),
                'patient_id': r[2],
                'patient_name': r[3]
            }
            for r in rows
        ]
    }